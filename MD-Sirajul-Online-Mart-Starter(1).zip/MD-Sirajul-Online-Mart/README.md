# MD Sirajul Online Mart — starter project

This is a starter web app (not a published website or Android APK). It includes a simple shop front and Firebase email/password + Google sign-in wiring.

## Enable login before use

1. Open https://console.firebase.google.com/ and create a Firebase project.
2. Add a Web app in Project settings and copy its Firebase config.
3. In `index.html`, replace the four `PASTE_...` values in `firebaseConfig`.
4. In Firebase Console → Authentication → Sign-in method, enable **Email/Password** and **Google**.
5. In Authentication → Settings → Authorized domains, add the domain where you host this app.
6. Open `index.html` using a local web server or deploy the folder to a static host (for example GitHub Pages). ES modules may not work if you open the file directly as `file://`.

## Important
- This is a starter template. It does not yet include real payments, inventory, order storage, admin panel, or a production security review.
- Never share your Firebase private credentials or passwords. Firebase web config is designed to be used in client apps, but security must be enforced with Firebase rules.
